const { app, shell, BrowserWindow, Tray, nativeImage } = require("electron");
const path = require("path");

require("update-electron-app")();

// require("electron-reload")(__dirname, {
//   electron: path.join(__dirname, "node_modules", ".bin", "electron"),
// });

let tray;

function toggleWindow() {
  trayWindow.isVisible() ? trayWindow.hide() : trayWindow.show();
}

app.dock.setIcon(path.join(__dirname, "/asset/logo.png"));
app.dock.hide();

app.whenReady().then(() => {
  const image = nativeImage.createFromPath(
    path.join(__dirname, "/asset/logo_32.png")
  );
  console.log(__dirname);
  image.resize({ width: 32 });
  // image.setTemplateImage(true);
  tray = new Tray(image);

  trayBounds = tray.getBounds();
  trayWindow = new BrowserWindow({
    width: 360,
    height: 640,
    frame: false,
    resizable: false,
    transparent: true,
    show: false,
    movable: false,
    minimizable: false,
    alwaysOnTop: false,
    skipTaskbar: false,
    maximizable: false,
    webPreferences: {
      backgroundThrottling: false,
      //   nodeIntegration: true,
      //   preload: path.join(__dirname, "preload.js"),
    },
  });
  trayWindow.loadURL("https://tab-ku-dev.vercel.app/");
  tray.addListener("click", (e, b, p) => {
    trayWindow.setPosition(b.x - 180 + b.width / 2, b.y - 200);
    toggleWindow();
  });
  trayWindow.addListener("blur", () => {
    trayWindow.hide();
  });
  app.addListener("browser-window-created", async (e, w) => {
    w.addListener("page-title-updated", (e, t) => {
      const url = e.sender.webContents.getURL();
      shell.openExternal(url);
      w.close();
    });
  });
  // createWindow();
});

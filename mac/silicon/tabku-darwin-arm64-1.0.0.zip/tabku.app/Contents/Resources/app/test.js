console.log(path.join(__dirname, "/asset/logo.png").toString());

module.exports = {
  publishers: [
    {
      name: "TabKU",
      config: {
        repository: {
          owner: "ziweek",
          name: "TabKU",
        },
        prerelease: false,
        draft: true,
      },
    },
  ],
  packagerConfig: {
    icon: "/asset/icon",
  },
  rebuildConfig: {},
  makers: [
    {
      name: "@electron-forge/maker-squirrel",
      config: {},
    },
    {
      name: "@electron-forge/maker-zip",
      platforms: ["darwin"],
      config: {
        setupIcon: "/asset/icon.icns",
      },
    },
    {
      name: "@electron-forge/maker-deb",
      config: {},
    },
    {
      name: "@electron-forge/maker-rpm",
      config: {},
    },
  ],
};
